export default function Footer() {
  return (
    <footer className="bg-white py-6">
      <div className="max-w-4xl mx-auto px-4 text-center text-gray-600">
        © 2025 Dapzsyz. All rights reserved.
      </div>
    </footer>
  );
}