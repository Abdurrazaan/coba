import Link from "next/link";

export default function Navbar() {
  return (
    <nav className="bg-white shadow-md fixed w-full z-10">
      <div className="max-w-6xl mx-auto px-4">
        <div className="flex items-center justify-between h-16">
          <div className="flex-shrink-0">
            <Link href="/" className="text-xl font-bold">
              Dapzsyz
            </Link>
          </div>
          <div className="flex space-x-4">
            <Link href="/" className="text-gray-700 hover:text-blue-500">Home</Link>
            <Link href="#about" className="text-gray-700 hover:text-blue-500">About</Link>
            <Link href="#features" className="text-gray-700 hover:text-blue-500">Features</Link>
            <Link href="#contact" className="text-gray-700 hover:text-blue-500">Contact</Link>
          </div>
        </div>
      </div>
    </nav>
  );
}