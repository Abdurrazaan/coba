"use client";
import { motion } from "framer-motion";

export default function Hero() {
  return (
    <section
      className="h-screen flex items-center justify-center bg-gradient-to-r from-indigo-500 to-purple-500"
      id="hero"
    >
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.8 }}
        className="text-center px-4"
      >
        <h1 className="text-5xl font-bold text-white mb-4">
          Selamat Datang di Dapzsyz Official
        </h1>
        <p className="text-xl text-white mb-6">
          Kami menghadirkan solusi terbaik untuk kebutuhan digital Anda.
        </p>
        <a
          href="#about"
          className="inline-block px-6 py-3 bg-white text-indigo-600 font-semibold rounded-lg hover:bg-gray-100"
        >
          Pelajari Lebih Lanjut
        </a>
      </motion.div>
    </section>
  );
}