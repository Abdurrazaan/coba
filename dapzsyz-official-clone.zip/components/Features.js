export default function Features() {
  return (
    <section id="features" className="py-16 bg-gray-100">
      <div className="max-w-4xl mx-auto px-4 text-center">
        <h2 className="text-3xl font-bold mb-8">Fitur Kami</h2>
        <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
          <div className="p-6 bg-white rounded-lg shadow-md">
            <h3 className="text-xl font-semibold mb-2">Kecepatan Tinggi</h3>
            <p className="text-gray-600">
              Sistem kami dioptimalkan untuk performa terbaik, sehingga loading sangat cepat.
            </p>
          </div>
          <div className="p-6 bg-white rounded-lg shadow-md">
            <h3 className="text-xl font-semibold mb-2">Desain Responsif</h3>
            <p className="text-gray-600">
              Tampilan nyaman di semua perangkat, baik desktop maupun mobile.
            </p>
          </div>
          <div className="p-6 bg-white rounded-lg shadow-md">
            <h3 className="text-xl font-semibold mb-2">Dukungan Lengkap</h3>
            <p className="text-gray-600">
              Tim support kami siap membantu Anda 24/7 untuk setiap kebutuhan.
            </p>
          </div>
        </div>
      </div>
    </section>
  );
}