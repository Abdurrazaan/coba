# Dapzsyz Official Clone

Proyek ini adalah contoh website menggunakan **Next.js** + **Tailwind CSS** + **Framer Motion**, dibuat menyerupai tampilan `dapzsyz-official.vercel.app`.

## 🚀 Cara Menjalankan

1. **Ekstrak file ZIP**
   ```bash
   unzip dapzsyz-official-clone.zip
   cd dapzsyz-official-clone
   ```

2. **Install dependencies**
   Pastikan Node.js sudah terinstall (disarankan versi LTS terbaru).
   ```bash
   npm install
   ```

3. **Jalankan server development**
   ```bash
   npm run dev
   ```

4. **Buka di browser**
   Akses [http://localhost:3000](http://localhost:3000)

## 📂 Struktur Folder

```
dapzsyz-official-clone/
├─ components/     # Komponen UI (Navbar, Hero, Features, Footer)
├─ pages/          # Halaman Next.js (index.js, _app.js)
├─ styles/         # File CSS global (Tailwind)
├─ package.json    # Konfigurasi project & dependencies
├─ tailwind.config.js
├─ postcss.config.js
└─ next.config.js
```

## 🛠 Teknologi yang Dipakai

- [Next.js](https://nextjs.org/) – React Framework
- [Tailwind CSS](https://tailwindcss.com/) – Utility-first CSS
- [Framer Motion](https://www.framer.com/motion/) – Animasi

## ✨ Fitur

- **Navbar** responsif
- **Hero section** dengan animasi
- **Features section** menggunakan grid
- **Footer** sederhana

---

📌 Setelah paham, kamu bisa modifikasi teks, warna, dan layout sesuai kebutuhan!
